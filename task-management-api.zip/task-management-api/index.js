const express = require('express');
const mongoose = require('mongoose');
const { graphqlHTTP } = require('express-graphql');
const schema = require('./src/schemas/index.js');
const authRoutes = require('./src/routes/auth');

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Use auth routes
app.use('/auth', authRoutes);

// GraphQL endpoint
app.use('/graphql', graphqlHTTP({
  schema,
  graphiql: true,
}));

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017")
  .then(() => app.listen(process.env.PORT || 4000, () => console.log('Server running')))
  .catch(err => console.error(err));
